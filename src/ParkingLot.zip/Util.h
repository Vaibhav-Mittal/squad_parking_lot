#ifndef __UTIL__
#define __UTIL__
#include <string>

namespace Util
{
	int strToInt(const std::string& str);
}

#endif // __UTIL__